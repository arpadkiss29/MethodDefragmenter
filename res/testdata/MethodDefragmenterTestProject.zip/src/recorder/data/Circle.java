package recorder.data;

public class Circle {
	private int X;
	private int Y;
	private int R;
	
	public Circle(int x, int y, int r) {
		super();
		X = x;
		Y = y;
		R = r;
	}

	public int getX() {
		return X;
	}

	public int getY() {
		return Y;
	}

	public int getR() {
		return R;
	}
}
