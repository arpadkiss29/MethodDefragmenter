package recorder;

import java.io.DataOutputStream;
import java.io.IOException;

import recorder.data.Circle;
import recorder.data.Rectangle;

public class Recorder {
	private DataOutputStream stream;

	public Recorder(DataOutputStream stream) {
		this.stream = stream;
	}
	
	public void persist(Object o) throws IOException {
		if(o instanceof Circle) {
			this.stream.writeInt(((Circle)o).getX());
			this.stream.writeInt(((Circle)o).getY());
			this.stream.writeInt(((Circle)o).getR());
		}
		
		if(o instanceof Rectangle) {
			this.stream.writeInt(((Rectangle)o).getX1());
			
			this.stream.writeInt(((Rectangle)o).getY1());
			this.stream.writeInt(((Rectangle)o).getX2());
			this.stream.writeInt(((Rectangle)o).getY2());
		}
	}
}
