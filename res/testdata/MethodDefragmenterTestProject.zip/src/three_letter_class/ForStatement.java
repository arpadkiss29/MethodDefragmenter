package three_letter_class;

import three_letter_class.data.ABC;
import three_letter_class.data.DEF;
import three_letter_class.data.ThreeLetterClass;

public class ForStatement {
	private int n = 5;
	
	public ThreeLetterClass forStatement() {
		ABC abc = new ABC();
		abc.setA(n);
		abc.setB(n);
		abc.setC(n);
		
		int s = 0;
		for (int i = 1; i <= n; i++) {
			s += abc.getA() + abc.getB() + abc.getC();
		}
		
		DEF def = new DEF();
		def.setD(s);
		def.setE(s);
		def.setF(s);
		
		System.out.println(s);
		
		return def;
	}
}
