package three_letter_class;

import three_letter_class.data.ABC;
import three_letter_class.data.DEF;
import three_letter_class.data.ThreeLetterClass;

public class SwitchStatement {
	private int n = 5;
	
	public ThreeLetterClass switchStatement(int i) {
		ABC abc = new ABC();
		abc.setA(n);
		abc.setB(n);
		abc.setC(n);
		
		i = i < 0 ? -1 : i == 0 ? 0 : 1;
		int s = 0;
		switch(i) {
			case -1:
				s += 3 * abc.getA();
				break;
			case 0:
				s += 3 * abc.getB();
				break;
			case 1:
				s += 3 * abc.getC();
		}
		
		DEF def = new DEF();
		def.setD(s);
		def.setE(s);
		def.setF(s);
		
		System.out.println(s);
		
		return def;
	}
}
