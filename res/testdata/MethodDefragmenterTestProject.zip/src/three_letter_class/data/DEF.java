package three_letter_class.data;

public class DEF extends ThreeLetterClass {
	private int D;
	private int E;
	private int F;
	
	public int getD() {
		return D;
	}
	
	public void setD(int d) {
		D = d;
	}
	
	public int getE() {
		return E;
	}
	
	public void setE(int e) {
		E = e;
	}
	
	public int getF() {
		return F;
	}
	
	public void setF(int f) {
		F = f;
	}
}
