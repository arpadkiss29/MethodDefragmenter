package three_letter_class.data;

public class ABC extends ThreeLetterClass {
	private int A;
	private int B;
	private int C;

	public int getA() {
		return A;
	}

	public void setA(int A) {
		this.A = A;
	}

	public int getB() {
		return B;
	}

	public void setB(int b) {
		B = b;
	}

	public int getC() {
		return C;
	}

	public void setC(int c) {
		C = c;
	}
}
