package three_letter_class.data;

public abstract class ThreeLetterClass {

}
