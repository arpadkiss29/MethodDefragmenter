package three_letter_class;

import three_letter_class.data.ABC;
import three_letter_class.data.DEF;
import three_letter_class.data.ThreeLetterClass;

public class DoWhileStatement {
	private int n = 5;
	
	public ThreeLetterClass doWhileStatement() {
		ABC abc = new ABC();
		abc.setA(n);
		abc.setB(n);
		abc.setC(n);
		
		int s = 0;
		int i = 1;
		do {
			s += abc.getA() + abc.getB() + abc.getC();
		} while (i <= n);
		
		DEF def = new DEF();
		def.setD(s);
		def.setE(s);
		def.setF(s);
		
		System.out.println(s);
		
		return def;
	}
}
