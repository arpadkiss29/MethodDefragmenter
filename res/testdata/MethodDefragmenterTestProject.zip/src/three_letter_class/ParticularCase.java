package three_letter_class;

import three_letter_class.data.ABC;
import three_letter_class.data.DEF;
import three_letter_class.data.ThreeLetterClass;

public class ParticularCase {
	private int n = 5;
	
	public ThreeLetterClass particularCase(int k) {
		ABC abc = new ABC();
		abc.setA(n);
		abc.setB(n);
		abc.setC(n);
		
		int new_n = n;
		for(int i = 1; i <= k; i++) {
			new_n *= 2;
			new_n++;
		}
		
		int a = abc.getA();
		int b = abc.getB();
		int c = abc.getC();
		
		int s = a + b + c + new_n;
		
		DEF def = new DEF();
		def.setD(s);
		def.setE(s);
		def.setF(s);
		
		return def;	
	}
}
